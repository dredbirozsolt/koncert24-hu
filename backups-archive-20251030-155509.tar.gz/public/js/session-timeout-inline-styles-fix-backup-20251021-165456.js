/**
 * Session Timeout Warning
 * Figyelmeztet a felhasználót, mielőtt a session lejár
 */

(function () {
  'use strict';

  // Konfiguráció
  const CONFIG = {
    sessionDuration: 24 * 60 * 60 * 1000, // 24 óra (development)
    warningTime: 2 * 60 * 1000, // 2 perc a lejárat előtt figyelmezt
    checkInterval: 30 * 1000, // 30 másodpercenként ellenőriz
    extendUrl: '/api/session/extend' // API endpoint a session meghosszabbításához
  };

  const LOGOUT_URL = '/auth/logout';

  let lastActivity = Date.now();
  let warningShown = false;
  let sessionCheckInterval = null;

  // Modal HTML
  function createWarningModal() {
    const modal = document.createElement('div');
    modal.id = 'session-timeout-modal';
    modal.innerHTML = `
      <div class="session-modal-overlay">
        <div class="session-modal-content">
          <div class="session-modal-icon">⏱️</div>
          <h2>Munkamenet hamarosan lejár</h2>
          <p>A munkamenete 2 percen belül lejár inaktivitás miatt.</p>
          <p>Szeretné meghosszabbítani?</p>
          <div class="session-modal-actions">
            <button id="session-extend-btn" class="session-btn session-btn-primary">
              ✅ Munkamenet meghosszabbítása
            </button>
            <button id="session-logout-btn" class="session-btn session-btn-secondary">
              🚪 Kijelentkezés most
            </button>
          </div>
          <div class="session-modal-timer">
            Automatikus kijelentkezés: <span id="session-countdown">120</span> másodperc
          </div>
        </div>
      </div>
    `;

    // Stílusok
    const style = document.createElement('style');
    style.textContent = `
      #session-timeout-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 999999;
      }

      #session-timeout-modal.show {
        display: block;
      }

      .session-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        align-items: center;
        justify-center;
        animation: fadeIn 0.3s ease;
      }

      .session-modal-content {
        background: white;
        padding: 2.5rem;
        border-radius: 16px;
        max-width: 450px;
        text-align: center;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        animation: slideIn 0.3s ease;
      }

      .session-modal-icon {
        font-size: 4rem;
        margin-bottom: 1rem;
      }

      .session-modal-content h2 {
        color: #333;
        margin-bottom: 1rem;
        font-size: 1.5rem;
      }

      .session-modal-content p {
        color: #666;
        margin-bottom: 0.5rem;
        line-height: 1.6;
      }

      .session-modal-actions {
        display: flex;
        gap: 1rem;
        margin-top: 1.5rem;
        flex-wrap: wrap;
      }

      .session-btn {
        flex: 1;
        padding: 0.875rem 1.5rem;
        border: none;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        min-width: 150px;
      }

      .session-btn-primary {
        background: #2563eb;
        color: white;
      }

      .session-btn-primary:hover {
        background: #1d4ed8;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
      }

      .session-btn-secondary {
        background: #6b7280;
        color: white;
      }

      .session-btn-secondary:hover {
        background: #4b5563;
      }

      .session-modal-timer {
        margin-top: 1.5rem;
        padding: 1rem;
        background: #fff3cd;
        border-radius: 8px;
        color: #856404;
        font-weight: 600;
      }

      #session-countdown {
        color: #d97706;
        font-size: 1.2rem;
      }

      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }

      @keyframes slideIn {
        from {
          transform: translateY(-50px);
          opacity: 0;
        }
        to {
          transform: translateY(0);
          opacity: 1;
        }
      }

      @media (max-width: 768px) {
        .session-modal-content {
          padding: 2rem;
          margin: 1rem;
          max-width: 90%;
        }

        .session-modal-actions {
          flex-direction: column;
        }

        .session-btn {
          width: 100%;
        }
      }
    `;

    document.head.appendChild(style);
    document.body.appendChild(modal);
    return modal;
  }

  // User aktivitás követése
  function resetActivity() {
    lastActivity = Date.now();
    warningShown = false;
  }

  // Ellenőrzi, hogy kell-e figyelmeztetni
  function checkTimeout() {
    const now = Date.now();
    const elapsed = now - lastActivity;
    const remaining = CONFIG.sessionDuration - elapsed;

    // Ha lejárt, kijelentkeztetés
    if (remaining <= 0) {
      window.location.href = LOGOUT_URL;
      return;
    }

    // Ha 2 percnél kevesebb van hátra és még nem jelent meg a modal
    if (remaining <= CONFIG.warningTime && !warningShown) {
      showWarning(remaining);
    }
  }

  // Figyelmeztető modal megjelenítése
  function showWarning(remainingTime) {
    warningShown = true;
    const modal = document.getElementById('session-timeout-modal') || createWarningModal();
    modal.classList.add('show');

    let countdown = Math.floor(remainingTime / 1000);
    const countdownEl = document.getElementById('session-countdown');

    // Countdown timer
    const countdownInterval = setInterval(() => {
      countdown -= 1;
      if (countdownEl) {
        countdownEl.textContent = countdown;
      }

      if (countdown <= 0) {
        clearInterval(countdownInterval);
        window.location.href = LOGOUT_URL;
      }
    }, 1000);

    // Meghosszabbítás gomb
    document.getElementById('session-extend-btn').onclick = function () {
      extendSession();
      modal.classList.remove('show');
      clearInterval(countdownInterval);
      resetActivity();
    };

    // Kijelentkezés gomb
    document.getElementById('session-logout-btn').onclick = function () {
      window.location.href = LOGOUT_URL;
    };
  }

  // Session meghosszabbítása
  function extendSession() {
    fetch(CONFIG.extendUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': getCsrfToken()
      },
      credentials: 'same-origin'
    })
      .then((response) => {
        if (response.ok) {
          console.log('✅ Session extended successfully');
          resetActivity();
        } else {
          console.error('❌ Failed to extend session');
        }
      })
      .catch((error) => {
        console.error('❌ Error extending session:', error);
      });
  }

  // CSRF token lekérése
  function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') : '';
  }

  // Aktivitás figyelők
  function setupActivityListeners() {
    const events = ['mousedown', 'keydown', 'scroll', 'touchstart', 'click'];
    events.forEach((event) => {
      document.addEventListener(event, resetActivity, { passive: true });
    });
  }

  // Cleanup function
  function cleanup() {
    if (sessionCheckInterval) {
      clearInterval(sessionCheckInterval);
      sessionCheckInterval = null;
    }
  }

  // Inicializálás
  function init() {
    // Csak bejelentkezett usereknek
    if (!document.body.classList.contains('logged-in')) {
      return;
    }

    setupActivityListeners();
    sessionCheckInterval = setInterval(checkTimeout, CONFIG.checkInterval);
    console.log('🔐 Session timeout warning initialized');
  }

  // Cleanup on page unload
  window.addEventListener('beforeunload', cleanup);

  // DOM ready után indítás
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
}());
